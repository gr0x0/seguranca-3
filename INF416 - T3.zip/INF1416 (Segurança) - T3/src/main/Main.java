package main;

import backend.ControladorBackend;

public class Main 
{
	public static void main(String[] args) throws ClassNotFoundException
	{
		ControladorBackend.getCtrlBE();
	}
}