package frames;

import javax.swing.JPanel;

public class PanelUser extends JPanel
{

}
