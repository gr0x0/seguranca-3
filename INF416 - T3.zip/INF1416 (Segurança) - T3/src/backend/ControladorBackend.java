package backend;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import frames.ControladorInterface;
import backend.Login;

public class ControladorBackend 
{
	static ControladorBackend ctrlBE = null;
	static ControladorInterface ctrlIF = null;
	private Account account;
	
	private ControladorBackend()
	{}
	
	public static ControladorBackend getCtrlBE() throws ClassNotFoundException
	{
		if(ctrlBE == null)
		{
			new Connect("C:/Sqlite/BDSeg");
			ctrlBE = new ControladorBackend();
			ctrlIF = ControladorInterface.getCtrlIF();
		}
		return ctrlBE;
	}
	

	public int setAccount(String acc) throws SQLException, CertificateException
	{
		account = Login.VerifyAcc(acc);
		if(account != null){
			System.out.println(account.getHexPass());
			return 2;
		}
		return 0;
	}
	
	public int setPassword(ArrayList<String> passwordValues) throws Exception
	{
		return(DigestCalculator.VerifyPassword(account.getHexPass(), DigestCalculator.PossiblesPassword(passwordValues), passwordValues.size()));
	}
	
	public int setSecret(String secretPhrase) throws Exception
	{
		String privatekey = DecryptKey.Decrypt(secretPhrase);
		if(privatekey == null){
			return 0;
		}
		account.setPrivateKey(DigitalSignature.loadPrivateKey(privatekey));
		if(account.getPrivateKey() == null){
			return 0;
		} else {
			if(DigitalSignature.TestSignature(account.getPrivateKey(), account.getCertificate().getPublicKey()) == 1){
				account.setGroupid(Query.getGroup(String.valueOf(account.getId())));
				account.setSecretPhrase(secretPhrase);
				return 1;
			}else{
				return 0;
			}
		}
		
	}
	
	public Account getAccount(){
		return account;
	}
	
	public String getListArchives(String path)
	{
		String secret = null;
		int digest = 0;
		try {
			
			secret = DecryptKey.Decrypt(account.getPrivateKey(), path);
			
		} catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			
			secret = DecryptKey.DecryptArchives(secret, path);
			digest = DigitalSignature.VerifyDigitalSignature(secret, account.getCertificate().getPublicKey(), path);
			
		} catch (InvalidKeyException | NoSuchAlgorithmException | UnsupportedEncodingException | NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException | InvalidKeySpecException | SignatureException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(digest==0){
			return "dig_inv";
		}
		
		return secret;
	}
	
	
	public String getArchive(String codname, String name, String type, String email, String group, String path)
	{
		String secret = null;
		int digest = 0;
		byte [] archive = null;
		String grupo = null;
		if(account.getGroupid() == 0){
			grupo = "administrador";
		}else if(account.getGroupid() == 1){
			grupo = "usuario";
		}
		
		if(Certificate.getEmail(0).equals(email) || grupo.equals(group)){
			
			try {
				
				secret = DecryptKey.Decrypt(account.getPrivateKey(), path, codname);
				
			} catch (InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				
				archive = DecryptKey.DecryptArchive(secret, path, codname);
				digest = DigitalSignature.VerifyDigitalSignature(archive, account.getCertificate().getPublicKey(), path, codname);
				
			} catch (InvalidKeyException | NoSuchAlgorithmException | UnsupportedEncodingException | NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException | InvalidKeySpecException | SignatureException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			if(digest==0){
				return "dig_inv";
			}
			
			Archive.WriteArchive(archive, name, type, path);
			
		}
		return "ok";
	}

}
